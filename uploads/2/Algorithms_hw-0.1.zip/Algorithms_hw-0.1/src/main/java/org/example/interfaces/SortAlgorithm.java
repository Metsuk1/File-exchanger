package org.example.interfaces;

public interface SortAlgorithm {
    void sort(int[] arr);
    String name();
}
