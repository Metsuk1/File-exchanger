package org.example.interfaces;

public interface SelectAlgorithm {
    int select(int[] arr, int k);
    String name();
}
